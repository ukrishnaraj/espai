define(function() {
	return (/^(?:checkbox|radio)$/i);
});
